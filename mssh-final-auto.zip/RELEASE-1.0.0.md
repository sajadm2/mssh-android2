# mssh 1.0.0 — Customer release preparation

This is release source, NOT a built or device-tested APK.

## Changes
- Version 1.0.0 (12), non-debuggable release build.
- Gold/navy mobile mousavi logo shown for 2 seconds on a fresh Activity launch.
- Rotation does not repeat a completed intro; returning to a live Activity does not repeat it.
- Quick Settings does not launch the intro; unlock is requested only when locked.
- Removed experimental wording; TCP-only and UDP limitations remain visible.

## Signing — do this once on your own trusted computer
Install a JDK, then run in a PRIVATE directory outside the repository:

```sh
keytool -genkeypair -keystore mssh-release.p12 -storetype PKCS12 -alias mssh -keyalg RSA -keysize 3072 -validity 10000
```
Enter a strong password interactively. Keep the key and password in secure, separate backups. Never upload the key as a repository file or send it in chat. Reuse this same key for every update. Losing it prevents updates over existing installs.

Encode locally (Python 3):

```sh
python -c "import base64,pathlib; pathlib.Path('keystore-base64.txt').write_text(base64.b64encode(pathlib.Path('mssh-release.p12').read_bytes()).decode())"
```

In GitHub repository Settings → Secrets and variables → Actions → New repository secret, set:

- `MSSH_KEYSTORE_BASE64`: contents of private keystore-base64.txt (base64 is NOT encryption).
- `MSSH_STORE_PASSWORD`: the keystore password.
- `MSSH_KEY_ALIAS`: mssh.
- `MSSH_KEY_PASSWORD`: same password for this PKCS12 key.

Delete the temporary base64 file after saving the secret. Do not log these values or add them to source. Anyone able to modify trusted workflows can potentially extract repository secrets: restrict repository write access and review workflow changes.

## GitHub ZIP build
1. Replace root mssh-final-auto.zip with the supplied archive.
2. Replace .github/workflows/build-final.yml with the supplied build-final.yml.
3. Configure the four secrets above, then Actions → Build mssh customer release → Run workflow.
4. Successful run uploads artifact mssh-1.0.0-release containing mssh-1.0.0.apk and SHA256SUMS.txt.
5. The workflow verifies the APK signature and never falls back to a debug key.

The workflow embedded in the source archive is intended for the ZIP-based repository, not an extracted-source checkout.

## Before sending to customers
- Back up profiles before uninstalling a debug-signed build; release-signed APK cannot update a differently signed APK.
- Install the release on a real phone and test the 2-second brand screen, server import, SSH host-key trust, VPN permission, real web traffic, disconnect, screen lock/unlock, notification, and tile on/off without dismissing the panel.
- Test invalid password, changed host key, missing saved credentials, network loss and recovery.
- Check both supported ABIs where possible (arm64-v8a and armeabi-v7a), and oldest/newest supported Android versions.
- Export/QR is not encrypted; do not share customer passwords publicly. No built-in customer accounts or credentials are provided.
- Only after successful build and device checks, distribute the signed APK privately to customers. No GitHub public release is automatically created.

Known limits: SSH TCP tunnel; UDP/UDPGW/V2Ray unsupported. An active tunnel or TCP latency result does not prove general internet availability. Android/OEM panel behavior still needs testing. Android's own launch screen may precede the 2-second in-app logo.
