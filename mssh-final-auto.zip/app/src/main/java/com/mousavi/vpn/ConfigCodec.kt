package com.mousavi.vpn

import android.util.Base64
import org.json.JSONObject
import java.util.UUID

/** mssh-only format. Imported configs never establish host-key trust. */
object ConfigCodec {
    fun encode(p: ServerProfile, includePassword: Boolean): String {
        val json = JSONObject().put("v", 1).put("name", p.name).put("host", p.host)
            .put("port", p.port).put("username", p.username)
        if (includePassword) json.put("password", p.password)
        return "mssh://" + Base64.encodeToString(json.toString().toByteArray(Charsets.UTF_8), Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)
    }
    fun decode(text: String): ServerProfile {
        val value = text.trim()
        require(value.length <= 16000 && value.startsWith("mssh://"))
        val j = JSONObject(String(Base64.decode(value.removePrefix("mssh://"), Base64.URL_SAFE or Base64.NO_WRAP), Charsets.UTF_8))
        require(j.getInt("v") == 1)
        val name = j.getString("name").trim()
        val host = j.getString("host").trim()
        val user = j.getString("username").trim()
        val port = j.getInt("port")
        val password = j.optString("password", "")
        require(name.isNotEmpty() && name.length <= 80 && host.isNotEmpty() && host.length <= 253)
        require(host.none { it.isWhitespace() || it in "/@?#\\" } && !host.contains("://"))
        require(user.isNotEmpty() && user.length <= 128 && port in 1..65535 && password.length <= 1024)
        return ServerProfile(UUID.randomUUID().toString(), name, host, port, user, password)
    }
}
