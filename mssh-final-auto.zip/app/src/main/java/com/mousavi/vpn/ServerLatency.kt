package com.mousavi.vpn

import android.os.SystemClock
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket

/** TCP connect latency, not ICMP ping or a guarantee of SSH authentication. */
object ServerLatency {
    suspend fun measure(profiles: List<ServerProfile>): Map<String, Long?> = coroutineScope {
        profiles.map { profile ->
            async(Dispatchers.IO) {
                val latency = try {
                    val address = InetAddress.getByName(profile.host)
                    val samples = mutableListOf<Long>()
                    repeat(2) {
                        try {
                            Socket().use { socket ->
                                val start = SystemClock.elapsedRealtime()
                                socket.connect(InetSocketAddress(address, profile.port), 2000)
                                samples += (SystemClock.elapsedRealtime() - start).coerceAtLeast(1)
                            }
                        } catch (_: java.io.IOException) { /* Unreachable sample. */ }
                    }
                    samples.takeIf { it.isNotEmpty() }?.sorted()?.let { it[it.size / 2] }
                } catch (_: java.io.IOException) { null }
                profile.id to latency
            }
        }.awaitAll().toMap()
    }
}
