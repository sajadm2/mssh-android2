package com.mousavi.vpn

import com.jcraft.jsch.ChannelDirectTCPIP
import com.jcraft.jsch.Session
import java.io.DataInputStream
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.Semaphore

/** Loopback-only SOCKS5 CONNECT bridge. UDP is deliberately rejected. */
class SshSocks(private val session: Session, private val token: String) : AutoCloseable {
    val requests = java.util.concurrent.atomic.AtomicLong()
    val opened = java.util.concurrent.atomic.AtomicLong()
    val failures = java.util.concurrent.atomic.AtomicLong()
    private val listener = ServerSocket(0, 32, InetAddress.getByName("127.0.0.1"))
    val port get() = listener.localPort
    private val sockets = ConcurrentHashMap.newKeySet<Socket>()
    private val pool = Executors.newCachedThreadPool()
    private val slots = Semaphore(64)
    fun start() { pool.execute {
        try { while (!listener.isClosed) {
            val socket = listener.accept()
            if (!slots.tryAcquire()) { socket.close(); continue }
            sockets.add(socket)
            pool.execute { try { serve(socket) } finally {
                sockets.remove(socket); runCatching { socket.close() }; slots.release()
            } }
        } } catch (_: Exception) { close() }
    } }
    private fun serve(socket: Socket) {
        var channel: ChannelDirectTCPIP? = null
        try {
            socket.soTimeout = 15000
            val input = DataInputStream(socket.getInputStream())
            val out = socket.getOutputStream()
            require(input.readUnsignedByte() == 5)
            val methods = ByteArray(input.readUnsignedByte()).also { input.readFully(it) }
            require(methods.contains(2.toByte()))
            out.write(byteArrayOf(5, 2)); out.flush()
            require(input.readUnsignedByte() == 1)
            fun field(): String = ByteArray(input.readUnsignedByte()).also { input.readFully(it) }.toString(Charsets.UTF_8)
            val user = field(); val password = field()
            if (user != "mssh" || password != token) { out.write(byteArrayOf(1, 1)); return }
            out.write(byteArrayOf(1, 0)); out.flush()
            require(input.readUnsignedByte() == 5)
            val command = input.readUnsignedByte()
            require(input.readUnsignedByte() == 0)
            val host = when (input.readUnsignedByte()) {
                1 -> InetAddress.getByAddress(ByteArray(4).also { input.readFully(it) }).hostAddress!!
                3 -> field()
                4 -> InetAddress.getByAddress(ByteArray(16).also { input.readFully(it) }).hostAddress!!
                else -> error("Address type")
            }
            val port = input.readUnsignedShort()
            if (command != 1) { out.write(byteArrayOf(5, 7, 0, 1, 0, 0, 0, 0, 0, 0)); return }
            requests.incrementAndGet()
            val c = session.openChannel("direct-tcpip") as ChannelDirectTCPIP
            channel = c
            c.setHost(host); c.setPort(port); c.setOrgIPAddress("127.0.0.1"); c.setOrgPort(socket.port)
            val remoteIn = c.inputStream
            val remoteOut = c.outputStream
            c.connect(15000)
            opened.incrementAndGet()
            out.write(byteArrayOf(5, 0, 0, 1, 0, 0, 0, 0, 0, 0)); out.flush()
            socket.soTimeout = 0
            pool.execute {
                try { input.copyTo(remoteOut); remoteOut.flush(); remoteOut.close() }
                catch (_: Exception) { c.disconnect(); runCatching { socket.close() } }
            }
            remoteIn.copyTo(out); out.flush()
        } catch (_: Exception) {
            failures.incrementAndGet()
            // Never log server destinations or credentials.
        } finally { channel?.disconnect() }
    }
    override fun close() {
        runCatching { listener.close() }
        sockets.forEach { runCatching { it.close() } }
        pool.shutdownNow()
    }
}
