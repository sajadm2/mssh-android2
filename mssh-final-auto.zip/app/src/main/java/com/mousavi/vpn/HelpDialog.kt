package com.mousavi.vpn

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties

@Composable
fun HelpDialog(onDismiss: () -> Unit) {
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            Column(Modifier.safeDrawingPadding().padding(20.dp)) {
                Text("راهنمای mssh", style = MaterialTheme.typography.headlineSmall,
                    color = MaterialTheme.colorScheme.primary)
                Text("نسخهٔ ${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE}) • راهنمای آفلاین")
                TextButton(onClick = onDismiss) { Text("بازگشت به تنظیمات") }
                Column(Modifier.weight(1f).verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    HelpSection("شروع سریع", "۱. در بخش سرورها، «افزودن سرور SSH» را بزنید و مشخصات دریافتی از مدیر سرور را وارد کنید.\n۲. برای اتصال بدون درخواست دوبارهٔ رمز، گزینهٔ ذخیرهٔ رمز را فعال کنید و پروفایل را ذخیره کنید.\n۳. سرور را انتخاب کنید و در صفحهٔ اتصال روی M بزنید.\n۴. در اولین اتصال، اثر انگشت کلید SSH را با مقدار معتبر دریافتی از مدیر سرور مقایسه و سپس تأیید کنید.\n۵. درخواست مجوز VPN اندروید را تأیید کنید. برای آزمون اتصال، یک سایت باز کنید.")
                    HelpSection("اتصال، قطع و انتخاب خودکار", "با لمس M اتصال شروع می‌شود و هنگام فعال بودن سرویس، لمس دوباره آن را قطع می‌کند.\nانتخاب خودکار، سروری با کمترین زمان اتصال TCP به پورت SSH را انتخاب می‌کند؛ این عدد سرعت دانلود یا تضمین ورود موفق نیست.\nسبز شدن M یعنی دست‌کم یک مسیر TCP باز شده؛ تضمین دسترسی کامل اینترنت نیست. خط TCP به‌ترتیب تعداد درخواست‌ها، مسیرهای بازشده و خطاها را نشان می‌دهد.")
                    HelpSection("میانبر M در بالای گوشی", "پردهٔ تنظیمات سریع را کامل باز کنید، ویرایش / مداد را بزنید و mssh را به میانبرهای فعال اضافه کنید. آیکون M تک‌رنگ است و رنگ آن را اندروید تعیین می‌کند.\nلمس میانبر بدون باز کردن برنامه به سرور انتخاب‌شده وصل می‌شود؛ لمس دوباره اتصال را قطع می‌کند. این میانبر انتخاب خودکار کمترین پینگ را اجرا نمی‌کند.\nابتدا رمز را ذخیره کنید و یک‌بار از داخل برنامه برای تأیید کلید و مجوز VPN وصل شوید. روی گوشی قفل‌شده ممکن است باز کردن قفل لازم باشد.\nاگر آیکون قدیمی باقی مانده، میانبر را حذف و دوباره اضافه کنید.")
                    HelpSection("اعلان اتصال", "اگر اعلان دیده نمی‌شود: تنظیمات گوشی ← برنامه‌ها ← mssh ← اعلان‌ها؛ اجازهٔ اعلان و دستهٔ «اتصال mssh» را فعال کنید، سپس قطع و وصل کنید. نام گزینه‌ها بسته به گوشی متفاوت است.\nاعلان فعال بودن سرویس را نشان می‌دهد و دکمهٔ قطع دارد. لمس خود اعلان برنامه را باز می‌کند. زمان و حجم مصرفی فعلاً داخل برنامه نمایش داده می‌شوند.")
                    HelpSection("ورود و اشتراک کانفیگ / QR", "در بخش سرورها از ابزارهای ورود کانفیگ استفاده کنید. برای خروجی گرفتن، روی «اشتراک / QR / کپی» پروفایل بزنید.\nفقط قالب مخصوص mssh پشتیبانی می‌شود؛ کانفیگ‌های NPV و V2Ray قابل ورود نیستند.\nرمز به‌صورت پیش‌فرض در خروجی قرار نمی‌گیرد. متن و QR رمزگذاری نشده‌اند؛ اگر رمز را اضافه کنید، هر فردی که خروجی را داشته باشد می‌تواند آن را بخواند. کانفیگ دارای رمز را عمومی منتشر نکنید.")
                    HelpSection("رفع مشکل اتصال و اینترنت", "اگر اتصال برقرار نمی‌شود، اینترنت عادی را با VPN خاموش آزمایش و آدرس، پورت، نام کاربری و رمز را بررسی کنید. پاسخ پینگ به‌تنهایی تأیید حساب SSH نیست.\nاگر SSH وصل است ولی سایت باز نمی‌شود، وضعیت اتصال و خط TCP را بررسی کنید. افزایش خطاها می‌تواند به محدودیت فورواردینگ سرور یا مقصد مربوط باشد.\nاگر DNS خصوصی روی نام میزبان مشخص تنظیم شده، برای آزمایش موقتاً آن را روی خودکار بگذارید و بعد تنظیم قبلی را برگردانید.\nتماس‌ها و بازی‌های نیازمند UDP ممکن است کار نکنند. اگر اینترنت از کار افتاد، VPN را قطع کنید.\nبرای پشتیبانی، شمارهٔ نسخه و تصویر وضعیت یا نام مرحلهٔ خطا را بفرستید؛ رمز، QR دارای رمز و اطلاعات حساس را ارسال نکنید.")
                    HelpSection("هشدار تغییر کلید سرور", "کلید سرور برای همان میزبان و پورت ذخیره و در اتصال‌های بعدی بررسی می‌شود. اگر کلید تغییر کند، برنامه اتصال را متوقف می‌کند.\nاین اتفاق ممکن است از تعویض واقعی سرور یا دخالت در اتصال باشد. هشدار را دور نزنید؛ ابتدا اثر انگشت جدید را از مسیر معتبر با مدیر سرور بررسی کنید.")
                    HelpSection("حریم خصوصی و محدودیت‌ها", "پروفایل‌ها و رمزهای اختیاری با AES-GCM و Android Keystore روی گوشی ذخیره می‌شوند. این حفاظت شامل متن کپی‌شده و QR نیست.\nاین نسخه تونل SSH برای TCP است؛ UDP عمومی، V2Ray، ورود NPV، کلید خصوصی، انتخاب برنامه‌ها و اتصال مجدد خودکار پشتیبانی نمی‌شوند.\nKill Switch داخلی پیاده‌سازی نشده است؛ با قطع VPN معمولاً اینترنت عادی برمی‌گردد، مگر تنظیمات سیستم آن را مسدود کنند.")
                }
            }
        }
    }
}

@Composable
private fun HelpSection(title: String, body: String) {
    var expanded by rememberSaveable { mutableStateOf(false) }
    Surface(shape = MaterialTheme.shapes.medium, color = MaterialTheme.colorScheme.surface) {
        Column(Modifier.fillMaxWidth().padding(12.dp)) {
            TextButton(onClick = { expanded = !expanded }, modifier = Modifier.fillMaxWidth()) {
                Text("${if (expanded) "−" else "+"}  $title", modifier = Modifier.fillMaxWidth())
            }
            if (expanded) Text(body, modifier = Modifier.padding(8.dp), style = MaterialTheme.typography.bodyLarge)
        }
    }
}
