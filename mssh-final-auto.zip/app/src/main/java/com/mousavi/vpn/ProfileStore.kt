package com.mousavi.vpn

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

data class ServerProfile(val id: String, val name: String, val host: String, val port: Int, val username: String, val password: String = "")
data class ProfileData(val profiles: List<ServerProfile>, val selectedId: String?)

/** Profile data, including opt-in saved passwords, is encrypted with Android Keystore. */
class ProfileStore(context: Context) {
    private val prefs = context.getSharedPreferences("mssh_profiles", Context.MODE_PRIVATE)
    private val alias = "mssh_profile_key_v1"
    private fun key(): SecretKey {
        val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (store.getKey(alias, null) as? SecretKey)?.let { return it }
        return KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore").apply {
            init(KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build())
        }.generateKey()
    }
    fun load(): ProfileData {
        val encoded = prefs.getString("data", null) ?: return ProfileData(emptyList(), null)
        val bytes = Base64.decode(encoded, Base64.NO_WRAP)
        require(bytes.size >= 28) { "Invalid encrypted profile data" }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, bytes.copyOfRange(0, 12)))
        val root = JSONObject(String(cipher.doFinal(bytes.copyOfRange(12, bytes.size)), Charsets.UTF_8))
        val array = root.getJSONArray("profiles")
        val profiles = (0 until array.length()).map { i ->
            val p = array.getJSONObject(i)
            ServerProfile(p.getString("id"), p.getString("name"), p.getString("host"), p.getInt("port"), p.getString("username"), p.optString("password", ""))
        }
        return ProfileData(profiles, root.optString("selected").takeIf { id -> profiles.any { it.id == id } })
    }
    fun save(data: ProfileData) {
        val array = JSONArray()
        data.profiles.forEach { p -> array.put(JSONObject().put("id", p.id).put("name", p.name)
            .put("host", p.host).put("port", p.port).put("username", p.username).put("password", p.password)) }
        val root = JSONObject().put("profiles", array).put("selected", data.selectedId ?: "")
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key())
        val encrypted = cipher.iv + cipher.doFinal(root.toString().toByteArray(Charsets.UTF_8))
        check(prefs.edit().putString("data", Base64.encodeToString(encrypted, Base64.NO_WRAP)).commit())
    }
}
