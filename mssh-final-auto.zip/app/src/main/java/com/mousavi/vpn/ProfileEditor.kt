package com.mousavi.vpn

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import java.util.UUID

@Composable
fun ProfileEditor(profile: ServerProfile?, onDismiss: () -> Unit, onSave: (ServerProfile) -> Unit) {
    var name by rememberSaveable { mutableStateOf(profile?.name ?: "") }
    var host by rememberSaveable { mutableStateOf(profile?.host ?: "") }
    var port by rememberSaveable { mutableStateOf(profile?.port?.toString() ?: "22") }
    var username by rememberSaveable { mutableStateOf(profile?.username ?: "") }
    var password by remember { mutableStateOf(profile?.password ?: "") }
    var savePassword by remember { mutableStateOf(!profile?.password.isNullOrEmpty()) }
    val parsedPort = port.toIntOrNull()
    val validHost = host.trim().let { value ->
        value.isNotEmpty() && value.length <= 253 &&
            value.none { it.isWhitespace() || it in "/@?#\\" } &&
            !value.contains("://")
    }
    val valid = name.isNotBlank() && validHost && parsedPort != null &&
        parsedPort in 1..65535 && username.isNotBlank()
    AlertDialog(onDismissRequest = onDismiss,
        title = { Text(if (profile == null) "افزودن SSH مستقیم" else "ویرایش سرور") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(value = name, onValueChange = { name = it.take(80) }, label = { Text("نام پروفایل") }, singleLine = true)
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                    OutlinedTextField(value = host, onValueChange = { host = it.take(253) }, label = { Text("Host / IP") }, singleLine = true,
                        isError = host.isNotEmpty() && !validHost)
                    OutlinedTextField(value = port, onValueChange = { port = it.filter { c -> c in '0'..'9' }.take(5) }, label = { Text("Port") }, singleLine = true,
                        isError = port.isNotEmpty() && (parsedPort == null || parsedPort !in 1..65535))
                    OutlinedTextField(value = username, onValueChange = { username = it.take(128) }, label = { Text("Username") }, singleLine = true)
                }
                OutlinedTextField(value = password, onValueChange = { password = it.take(1024) }, label = { Text("رمز SSH") }, singleLine = true,
                    visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation())
                Row { Checkbox(checked = savePassword, onCheckedChange = { savePassword = it }); Text("ذخیرهٔ رمز به‌صورت رمزگذاری‌شده روی گوشی") }
                Text("فقط آدرس میزبان را وارد کنید؛ بدون https:// یا مسیر. اگر ذخیرهٔ رمز خاموش باشد، رمز هنگام اتصال پرسیده می‌شود.")
            }
        },
        confirmButton = {
            TextButton(enabled = valid, onClick = {
                onSave(ServerProfile(profile?.id ?: UUID.randomUUID().toString(), name.trim(), host.trim(), parsedPort!!, username.trim(), if (savePassword) password else ""))
            }) { Text("ذخیره") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } })
}
