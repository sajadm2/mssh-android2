package com.mousavi.vpn

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.widthIn
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp

@Composable
fun BrandSplash() {
    Box(
        modifier = Modifier.fillMaxSize().background(Color(0xFF101C30)),
        contentAlignment = Alignment.Center
    ) {
        Image(
            painter = painterResource(R.drawable.brand_splash),
            contentDescription = "mobile mousavi",
            modifier = Modifier.widthIn(max = 360.dp).fillMaxWidth(0.85f)
        )
    }
}
