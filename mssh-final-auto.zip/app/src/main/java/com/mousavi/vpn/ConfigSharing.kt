package com.mousavi.vpn

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.os.Build
import android.os.PersistableBundle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.google.zxing.*
import com.google.zxing.common.HybridBinarizer
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun ImportControls(enabled: Boolean, onImport: (ServerProfile) -> Unit, onError: (String) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    fun accept(value: String) {
        try { onImport(ConfigCodec.decode(value)) }
        catch (_: Exception) { onError("کانفیگ معتبر mssh پیدا نشد؛ فرمت‌های npvt و V2Ray پشتیبانی نمی‌شوند.") }
    }
    val scan = rememberLauncherForActivityResult(ScanContract()) { result -> result.contents?.let { accept(it) } }
    val image = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) scope.launch {
            val text = withContext(Dispatchers.IO) {
                try {
                    val bitmap = if (Build.VERSION.SDK_INT >= 28) {
                        ImageDecoder.decodeBitmap(ImageDecoder.createSource(context.contentResolver, uri)) { decoder, info, _ ->
                            decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                            val scale = minOf(1.0, 1600.0 / maxOf(info.size.width, info.size.height))
                            decoder.setTargetSize(maxOf(1, (info.size.width * scale).toInt()), maxOf(1, (info.size.height * scale).toInt()))
                        }
                    } else {
                        val bounds = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
                        context.contentResolver.openInputStream(uri).use { android.graphics.BitmapFactory.decodeStream(it, null, bounds) }
                        val options = android.graphics.BitmapFactory.Options().apply { inSampleSize = 1 }
                        while (maxOf(bounds.outWidth, bounds.outHeight) / options.inSampleSize > 1600) options.inSampleSize *= 2
                        context.contentResolver.openInputStream(uri).use { android.graphics.BitmapFactory.decodeStream(it, null, options) } ?: error("Image")
                    }
                    try {
                        val pixels = IntArray(bitmap.width * bitmap.height)
                        bitmap.getPixels(pixels, 0, bitmap.width, 0, 0, bitmap.width, bitmap.height)
                        MultiFormatReader().decode(BinaryBitmap(HybridBinarizer(RGBLuminanceSource(bitmap.width, bitmap.height, pixels)))).text
                    } finally { bitmap.recycle() }
                } catch (_: Exception) { null }
            }
            if (text == null) onError("QR قابل خواندن در تصویر پیدا نشد.") else accept(text)
        }
    }
    Column {
        OutlinedButton(enabled = enabled, onClick = {
            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            accept(clipboard.primaryClip?.getItemAt(0)?.text?.toString().orEmpty())
        }) { Text("ورود از کلیپ‌بورد") }
        Row {
            TextButton(enabled = enabled, onClick = { scan.launch(ScanOptions().setDesiredBarcodeFormats(ScanOptions.QR_CODE).setPrompt("QR کانفیگ mssh").setBeepEnabled(false)) }) { Text("اسکن QR") }
            TextButton(enabled = enabled, onClick = { image.launch("image/*") }) { Text("QR از تصویر") }
        }
    }
}

@Composable
fun ExportDialog(profile: ServerProfile, onDismiss: () -> Unit) {
    val context = LocalContext.current
    var includePassword by remember { mutableStateOf(false) }
    var copied by remember { mutableStateOf(false) }
    val text = remember(profile, includePassword) { ConfigCodec.encode(profile, includePassword) }
    val bitmap = remember(text) {
        try {
            val matrix = MultiFormatWriter().encode(text, BarcodeFormat.QR_CODE, 640, 640)
            Bitmap.createBitmap(640, 640, Bitmap.Config.ARGB_8888).apply {
                setPixels(IntArray(640 * 640) { i -> if (matrix[i % 640, i / 640]) android.graphics.Color.BLACK else android.graphics.Color.WHITE }, 0, 640, 0, 0, 640, 640)
            }
        } catch (_: Exception) { null }
    }
    DisposableEffect(bitmap) { onDispose { bitmap?.recycle() } }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("اشتراک کانفیگ mssh") }, text = {
        Column {
            if (profile.password.isNotEmpty()) Row {
                Checkbox(checked = includePassword, onCheckedChange = { includePassword = it; copied = false })
                Text("رمز هم داخل کانفیگ باشد")
            }
            Text("کانفیگ اشتراکی رمزگذاری نشده است؛ هر کس متن یا QR را داشته باشد می‌تواند محتویات آن را بخواند.")
            bitmap?.let { Image(it.asImageBitmap(), "QR کانفیگ", Modifier.size(240.dp)) }
                ?: Text("کانفیگ برای QR بزرگ است؛ از کپی استفاده کنید.")
            if (copied) Text("کپی شد")
        }
    }, confirmButton = { TextButton(onClick = {
        val clip = ClipData.newPlainText("mssh config", text)
        if (includePassword) clip.description.extras = PersistableBundle().apply { putBoolean("android.content.extra.IS_SENSITIVE", true) }
        (context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(clip)
        copied = true
    }) { Text("کپی کانفیگ") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("بستن") } })
}
