package com.mousavi.vpn

import android.app.*
import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor
import android.os.SystemClock
import android.util.Base64
import com.jcraft.jsch.*
import hev.htproxy.TProxyService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.net.InetSocketAddress
import java.net.Socket
import java.security.MessageDigest
import java.util.UUID
import java.util.concurrent.Executors

// Secrets never go into an Intent, saved state, logs or persistent preferences.
data class ConnectRequest(val profile: ServerProfile, var password: String, val fingerprint: String)
data class TunnelStatus(val text: String = "متصل نیستید", val active: Boolean = false,
    val connected: Boolean = false, val seconds: Long = 0, val upload: Long = 0, val download: Long = 0)
object TunnelState {
    private val mutable = MutableStateFlow(TunnelStatus())
    val status = mutable.asStateFlow()
    @Volatile var pending: ConnectRequest? = null
    fun update(value: TunnelStatus) { mutable.value = value }
}

class MsshVpnService : VpnService() {
    private val worker = Executors.newSingleThreadExecutor()
    @Volatile private var cancelled = false
    @Volatile private var started = false
    @Volatile private var session: Session? = null
    private var socks: SshSocks? = null
    private var tun: ParcelFileDescriptor? = null
    private var native: TProxyService? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") { stopTunnel(); return START_NOT_STICKY }
        if (started) return START_NOT_STICKY
        val request = TunnelState.pending ?: run { stopSelf(); return START_NOT_STICKY }
        TunnelState.pending = null
        started = true; cancelled = false
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(NotificationChannel("vpn", "اتصال mssh", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(this, 2, Intent(this, MsshVpnService::class.java).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE)
        val open = PendingIntent.getActivity(this, 1, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val notification = Notification.Builder(this, "vpn").setContentTitle("mssh")
            .setContentText("سرویس تونل فعال است؛ وضعیت اتصال را داخل برنامه ببینید")
            .setSmallIcon(com.mousavi.vpn.R.drawable.ic_launcher).setContentIntent(open)
            .setOngoing(true).addAction(Notification.Action.Builder(null, "قطع", stop).build()).build()
        startForeground(1, notification)
        TunnelState.update(TunnelStatus("در حال اتصال SSH…", active = true))
        worker.execute { connect(request) }
        return START_NOT_STICKY
    }

    private fun connect(request: ConnectRequest) {
        var failure: String? = null
        var stage = "بررسی اثر انگشت"
        var keyMismatch = false
        try {
            val expected = request.fingerprint.trim().removePrefix("SHA256:").trimEnd('=')
            require(expected.matches(Regex("[A-Za-z0-9+/]{43}")))
            val jsch = JSch()
            jsch.setHostKeyRepository(object : HostKeyRepository {
                override fun check(host: String?, key: ByteArray?): Int {
                    if (key == null) { keyMismatch = true; return HostKeyRepository.CHANGED }
                    val digest = Base64.encodeToString(MessageDigest.getInstance("SHA-256").digest(key), Base64.NO_WRAP or Base64.NO_PADDING)
                    val matches = MessageDigest.isEqual(digest.toByteArray(), expected.toByteArray())
                    if (!matches) keyMismatch = true
                    return if (matches) HostKeyRepository.OK else HostKeyRepository.CHANGED
                }
                override fun add(hostkey: HostKey?, ui: UserInfo?) = Unit
                override fun remove(host: String?, type: String?) = Unit
                override fun remove(host: String?, type: String?, key: ByteArray?) = Unit
                override fun getKnownHostsRepositoryID(): String = "mssh pinned SHA256"
                override fun getHostKey(): Array<HostKey> = emptyArray()
                override fun getHostKey(host: String?, type: String?): Array<HostKey> = emptyArray()
            })
            val p = request.profile
            val ssh = jsch.getSession(p.username, p.host, p.port)
            session = ssh
            ssh.setConfig("StrictHostKeyChecking", "yes")
            ssh.setConfig("PreferredAuthentications", "password")
            ssh.setPassword(request.password)
            request.password = ""
            ssh.setServerAliveInterval(15000)
            ssh.setServerAliveCountMax(3)
            ssh.setSocketFactory(object : SocketFactory {
                override fun createSocket(host: String, port: Int): Socket {
                    val socket = Socket()
                    try {
                        // Force creation of the OS socket before VpnService.protect reads its fd.
                        // Do not connect first: SSH traffic must never enter our VPN route.
                        socket.bind(InetSocketAddress(0))
                        check(protect(socket)) { "Socket protection failed" }
                        socket.connect(InetSocketAddress(host, port), 15000)
                        socket.tcpNoDelay = true
                        return socket
                    } catch (e: Exception) { socket.close(); throw e }
                }
                override fun getInputStream(socket: Socket) = socket.getInputStream()
                override fun getOutputStream(socket: Socket) = socket.getOutputStream()
            })
            stage = "مذاکره و ورود SSH"
            ssh.connect(20000)
            check(!cancelled)
            stage = "راه‌اندازی پل SOCKS"
            val token = UUID.randomUUID().toString().replace("-", "")
            val bridge = SshSocks(ssh, token)
            socks = bridge; bridge.start()
            val config = java.io.File(filesDir, "tunnel.yml")
            config.writeText("""
                tunnel:
                  name: mssh
                  mtu: 1500
                  ipv4: 198.18.0.1
                  ipv6: 'fd00::1'
                socks5:
                  address: 127.0.0.1
                  port: ${bridge.port}
                  username: mssh
                  password: '$token'
                mapdns:
                  address: 198.18.0.2
                  port: 53
                  network: 100.64.0.0
                  netmask: 255.192.0.0
                  cache-size: 4096
                misc:
                  max-session-count: 64
                  connect-timeout: 15000
                  log-level: error
            """.trimIndent())
            check(!cancelled)
            stage = "دریافت رابط VPN از اندروید"
            val descriptor = Builder().setSession("mssh SSH").setMtu(1500)
                .addAddress("198.18.0.1", 30).addAddress("fd00::1", 128)
                .addRoute("0.0.0.0", 0).addRoute("::", 0)
                .addDnsServer("198.18.0.2").setBlocking(false).establish()
                ?: error("VPN permission unavailable")
            tun = descriptor
            stage = "راه‌اندازی موتور HEV"
            val engine = TProxyService(); native = engine
            check(engine.TProxyStartService(config.absolutePath, descriptor.fd))
            stage = "نگهداری اتصال تونل"
            val since = SystemClock.elapsedRealtime()
            while (!cancelled) {
                Thread.sleep(1000)
                check(ssh.isConnected && engine.TProxyIsRunning())
                val stats = engine.TProxyGetStats()
                TunnelState.update(TunnelStatus("تونل TCP برقرار است", true, true,
                    (SystemClock.elapsedRealtime() - since) / 1000, stats[1], stats[3]))
            }
        } catch (e: Throwable) {
            if (!cancelled) {
                // Inspect locally; never display or log exception messages (may contain secrets).
                val causes = generateSequence(e) { it.cause }.take(8).toList()
                val messages = causes.mapNotNull { it.message }.joinToString(" ").lowercase(java.util.Locale.ROOT)
                val reason = when {
                    keyMismatch -> "کلید سرور با کلید تأییدشده متفاوت است؛ هویت سرور را بررسی کنید."
                    causes.any { it is java.net.UnknownHostException } -> "آدرس سرور به IP تبدیل نشد."
                    causes.any { it is java.net.SocketTimeoutException } || "timeout" in messages -> "مهلت اتصال تمام شد."
                    causes.any { it is java.net.ConnectException } -> "برقراری اتصال TCP رد شد یا ممکن نبود."
                    "auth fail" in messages || "auth cancel" in messages -> "ورود SSH رد شد؛ اطلاعات حساب یا روش ورود موردنیاز سرور را بررسی کنید."
                    "algorithm negotiation" in messages -> "الگوریتم‌های SSH برنامه و سرور سازگار نیستند."
                    causes.any { it is UnsatisfiedLinkError } -> "کتابخانهٔ بومی HEV بارگذاری نشد."
                    "socket protection failed" in messages -> "اندروید نتوانست سوکت SSH را از مسیر VPN خارج کند."
                    else -> "علت دقیق شناسایی نشد؛ کد مرحله را برای بررسی ارسال کنید."
                }
                failure = "خطا در مرحلهٔ «$stage»: $reason"
            }
        } finally {
            request.password = ""
            runCatching { native?.TProxyStopService() }; native = null
            runCatching { tun?.close() }; tun = null
            runCatching { socks?.close() }; socks = null
            session?.disconnect(); session = null
            java.io.File(filesDir, "tunnel.yml").delete()
            TunnelState.update(TunnelStatus(failure ?: "متصل نیستید"))
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }
    private fun stopTunnel() { cancelled = true; session?.disconnect() }
    override fun onRevoke() { stopTunnel(); super.onRevoke() }
    override fun onDestroy() { stopTunnel(); worker.shutdown(); super.onDestroy() }
}
