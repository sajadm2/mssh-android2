package com.mousavi.vpn

import android.os.Bundle
import android.app.Activity
import android.net.VpnService
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import android.content.Intent
import android.net.Uri
import androidx.compose.ui.platform.LocalContext
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import androidx.compose.ui.unit.sp

private val Gold = Color(0xFFE4C688)
private val Panel = Color(0xFF1C2A40)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Gold, surface = Panel, background = Color(0xFF101A2C))) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) { App() }
            }
        }
    }
}

@Composable
private fun App() {
    val context = LocalContext.current
    val status by TunnelState.status.collectAsState()
    val scope = rememberCoroutineScope()
    val preferences = remember { context.getSharedPreferences("mssh_options", android.content.Context.MODE_PRIVATE) }
    var automatic by remember { mutableStateOf(preferences.getBoolean("automatic", false)) }
    var measuring by remember { mutableStateOf(false) }
    var latencies by remember { mutableStateOf<Map<String, Long?>>(emptyMap()) }
    var connectionProfile by remember { mutableStateOf<ServerProfile?>(null) }
    var showConnect by remember { mutableStateOf(false) }
    var password by remember { mutableStateOf("") }
    var fingerprint by remember { mutableStateOf("") }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            context.startForegroundService(Intent(context, MsshVpnService::class.java))
        } else {
            TunnelState.pending?.password = ""
            TunnelState.pending = null
        }
    }
    val store = remember { ProfileStore(context) }
    var storageError by remember { mutableStateOf(false) }
    var data by remember {
        mutableStateOf(try { store.load() } catch (_: Exception) {
            storageError = true
            ProfileData(emptyList(), null)
        })
    }
    var editing by remember { mutableStateOf<ServerProfile?>(null) }
    var showEditor by remember { mutableStateOf(false) }
    var pendingDelete by remember { mutableStateOf<ServerProfile?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    val selected = data.profiles.find { it.id == data.selectedId }
    fun persist(next: ProfileData) {
        try { store.save(next); data = next } catch (_: Exception) {
            error = "ذخیرهٔ امن انجام نشد؛ تغییری اعمال نشده است."
        }
    }
    var tab by rememberSaveable { mutableIntStateOf(0) }
    Scaffold(
        bottomBar = {
            NavigationBar(containerColor = Panel) {
                listOf("اتصال", "سرورها", "تنظیمات").forEachIndexed { index, title ->
                    NavigationBarItem(selected = tab == index, onClick = { tab = index },
                        icon = { Text(listOf("◉", "☰", "⚙")[index]) }, label = { Text(title) })
                }
            }
        }
    ) { padding ->
        Column(
            Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF17243A), Color(0xFF090F1C))))
                .padding(padding).verticalScroll(rememberScrollState()).padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(22.dp)
        ) {
            Text("mssh • ${BuildConfig.VERSION_NAME}", color = Gold, fontSize = 22.sp)
            Text("M", color = Color(0xFFFF303B), fontSize = 52.sp)
            if (storageError) Text("خواندن پروفایل‌های رمزگذاری‌شده ممکن نشد. برای حفظ داده‌ها، ویرایش غیرفعال است.", color = Color(0xFFFF8080))
            when (tab) {
                0 -> {
                    val displayedProfile = if (automatic) connectionProfile else selected
                    InfoCard(if (automatic) "انتخاب خودکار" else "سرور انتخاب‌شده", displayedProfile?.let { "${it.name}\n${it.host}:${it.port}" } ?: if (automatic) "با زدن اتصال، سریع‌ترین سرور بررسی و انتخاب می‌شود" else "هنوز سروری انتخاب نشده است")
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = automatic, enabled = !status.active && !measuring, onCheckedChange = {
                            automatic = it
                            preferences.edit().putBoolean("automatic", it).apply()
                        })
                        Text("انتخاب خودکار کمترین پینگ")
                    }
                    Text("معیار: زمان اتصال TCP به پورت SSH؛ نه سرعت دانلود", fontSize = 12.sp)
                    if (measuring) { CircularProgressIndicator(); Text("در حال بررسی سرورها…") }
                    Spacer(Modifier.height(12.dp))
                    Button(enabled = !measuring, onClick = {
                        if (status.active) context.startService(Intent(context, MsshVpnService::class.java).setAction("STOP"))
                        else if (data.profiles.isEmpty()) tab = 1
                        else if (automatic) {
                            val candidates = data.profiles.toList()
                            measuring = true
                            scope.launch {
                                try {
                                    val results = ServerLatency.measure(candidates)
                                    latencies = results
                                    val best = candidates.filter { results[it.id] != null }
                                        .minByOrNull { results[it.id]!! }
                                    if (best == null) error = "هیچ سروری پاسخ نداد؛ شبکه یا مشخصات سرورها را بررسی کنید."
                                    else {
                                        connectionProfile = best
                                        fingerprint = ""; password = ""
                                        showConnect = true
                                    }
                                } finally { measuring = false }
                            }
                        } else if (selected == null) tab = 1
                        else { connectionProfile = selected; fingerprint = ""; password = ""; showConnect = true }
                    }, shape = CircleShape,
                        modifier = Modifier.size(164.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Panel,
                            contentColor = if (status.connected) Color(0xFF32D583) else Color(0xFFFF303B))) {
                        Text("M", fontSize = 88.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Black)
                    }
                    Text(status.text, fontSize = 20.sp)
                    Text("%02d:%02d:%02d".format(status.seconds / 3600, status.seconds / 60 % 60, status.seconds % 60), fontSize = 30.sp)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Box(Modifier.weight(1f)) { InfoCard("دانلود", "${status.download / 1024} KiB") }
                        Box(Modifier.weight(1f)) { InfoCard("آپلود", "${status.upload / 1024} KiB") }
                    }
                    Text("نسخهٔ آزمایشی SSH مستقیم • فقط TCP • UDP عمومی پشتیبانی نمی‌شود", color = Gold, fontSize = 13.sp)
                }
                1 -> {
                    Button(enabled = !storageError, onClick = { editing = null; showEditor = true }) { Text("افزودن سرور SSH") }
                    if (data.profiles.isEmpty()) InfoCard("پروفایل‌های SSH", "برای شروع، آدرس و مشخصات سرور را اضافه کنید. رمز در این مرحله دریافت نمی‌شود.")
                    data.profiles.forEach { profile ->
                        Surface(shape = RoundedCornerShape(20.dp), color = Panel) {
                            Column(Modifier.fillMaxWidth().padding(16.dp)) {
                                Text(profile.name, color = Gold)
                                Text("${profile.host}:${profile.port}")
                                Text(profile.username)
                                if (latencies.containsKey(profile.id)) Text(latencies[profile.id]?.let { "TCP: $it ms" } ?: "بدون پاسخ")
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    TextButton(enabled = !storageError && !automatic && !measuring && !status.active, onClick = { persist(data.copy(selectedId = profile.id)) }) {
                                        Text(if (selected?.id == profile.id) "انتخاب‌شده ✓" else "انتخاب")
                                    }
                                    TextButton(enabled = !storageError, onClick = { editing = profile; showEditor = true }) { Text("ویرایش") }
                                    TextButton(enabled = !storageError, onClick = { pendingDelete = profile }) { Text("حذف") }
                                }
                            }
                        }
                    }
                }
                2 -> {
                    InfoCard("نسخهٔ برنامه", "${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE}) — اصلاح آماده‌سازی سوکت؛ نیازمند تست روی گوشی")
                    OutlinedButton(onClick = {
                        try {
                            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/light_elc")))
                        } catch (_: android.content.ActivityNotFoundException) {
                            error = "برای باز کردن لینک، مرورگر یا تلگرام نصب کنید."
                        }
                    }, modifier = Modifier.fillMaxWidth()) {
                        Text("پشتیبانی تلگرام — @light_elc")
                    }
                    InfoCard("محدودیت‌ها", "UDP، اتصال مجدد خودکار، کلید خصوصی، انتخاب برنامه‌ها و ورود کانفیگ npvt هنوز پشتیبانی نمی‌شوند. با قطع سرویس، اینترنت عادی برمی‌گردد؛ Kill Switch پیاده‌سازی نشده است.")
                    InfoCard("حریم خصوصی", "پروفایل‌ها با AES-GCM و کلید Android Keystore ذخیره می‌شوند. رمز SSH فقط هنگام اتصال در حافظه نگهداری می‌شود. هیچ اطلاعاتی خودکار برای پشتیبانی ارسال نمی‌شود.")
                }
            }
        }
    }
    if (showEditor) ProfileEditor(editing, onDismiss = { showEditor = false }, onSave = { profile ->
        val profiles = data.profiles.filterNot { it.id == profile.id } + profile
        persist(ProfileData(profiles, data.selectedId ?: profile.id))
        showEditor = false
    })
    pendingDelete?.let { profile ->
        AlertDialog(onDismissRequest = { pendingDelete = null }, title = { Text("حذف پروفایل؟") },
            text = { Text(profile.name) }, confirmButton = {
                TextButton(onClick = {
                    val remaining = data.profiles.filterNot { it.id == profile.id }
                    persist(ProfileData(remaining, if (data.selectedId == profile.id) remaining.firstOrNull()?.id else data.selectedId))
                    pendingDelete = null
                }) { Text("حذف") }
            }, dismissButton = { TextButton(onClick = { pendingDelete = null }) { Text("انصراف") } })
    }
    error?.let { message ->
        AlertDialog(onDismissRequest = { error = null }, title = { Text("خطا") }, text = { Text(message) },
            confirmButton = { TextButton(onClick = { error = null }) { Text("بستن") } })
    }
    if (showConnect) {
        var loadingKey by remember { mutableStateOf(true) }
        var trustedKey by remember { mutableStateOf(false) }
        var acceptKey by remember { mutableStateOf(false) }
        var keyError by remember { mutableStateOf<String?>(null) }
        LaunchedEffect(connectionProfile) {
            fingerprint = ""
            val profile = connectionProfile
            try {
                if (profile != null) {
                    val saved = HostTrust.saved(context, profile)
                    if (saved != null) { fingerprint = saved; trustedKey = true }
                    else fingerprint = HostTrust.discover(profile)
                }
            } catch (e: kotlinx.coroutines.CancellationException) { throw e
            } catch (_: Exception) {
                keyError = "دریافت کلید سرور ممکن نشد؛ اینترنت، آدرس و پورت را بررسی کنید و دوباره تلاش کنید."
            } finally { loadingKey = false }
        }
        AlertDialog(onDismissRequest = { showConnect = false; password = "" },
            title = { Text("اتصال به ${connectionProfile?.name.orEmpty()}") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("فقط رمز SSH را وارد کنید. کلید سرور خودکار دریافت و پس از تأیید ذخیره می‌شود.")
                    OutlinedTextField(value = password, onValueChange = { password = it }, singleLine = true,
                        label = { Text("رمز SSH") }, visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation())
                    if (loadingKey) { CircularProgressIndicator(); Text("در حال دریافت کلید سرور…") }
                    keyError?.let { Text(it, color = Color(0xFFFF8080)) }
                    if (trustedKey) Text("کلید ذخیره‌شده هنگام اتصال بررسی می‌شود؛ تغییر کلید باعث توقف اتصال خواهد شد.")
                    else if (fingerprint.isNotEmpty()) {
                        Text(fingerprint, style = MaterialTheme.typography.bodySmall)
                        Text("اولین اتصال: بدون مقایسه با مقدار معتبر، هویت سرور تضمین نمی‌شود. فقط در صورت اعتماد به این اتصال تأیید کنید.")
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = acceptKey, onCheckedChange = { acceptKey = it })
                            Text("به این کلید اعتماد دارم؛ ذخیره شود")
                        }
                    }
                    Text("این نسخه آزمایشی است. TCP تونل می‌شود؛ تماس‌ها و بازی‌های نیازمند UDP ممکن است کار نکنند. هنگام قطع VPN اینترنت عادی برمی‌گردد.")
                }
            },
            confirmButton = { TextButton(enabled = password.isNotEmpty() && !loadingKey && fingerprint.isNotEmpty() && (trustedKey || acceptKey), onClick = {
                connectionProfile?.let { profile ->
                    if (!trustedKey && !HostTrust.save(context, profile, fingerprint)) {
                        error = "ذخیرهٔ کلید سرور انجام نشد؛ اتصال متوقف شد."
                        return@let
                    }
                    TunnelState.pending = ConnectRequest(profile, password, fingerprint.trim())
                    password = ""; showConnect = false
                    val consent = VpnService.prepare(context)
                    if (consent == null) context.startForegroundService(Intent(context, MsshVpnService::class.java))
                    else permissionLauncher.launch(consent)
                }
            }) { Text("اتصال") } },
            dismissButton = { TextButton(onClick = { showConnect = false; password = "" }) { Text("انصراف") } })
    }
}

@Composable
private fun InfoCard(title: String, value: String) {
    Surface(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp), color = Panel) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, color = Color(0xFF8E9EB5), fontSize = 13.sp)
            Text(value, color = Color(0xFFF0F4FB), fontSize = 16.sp)
        }
    }
}
