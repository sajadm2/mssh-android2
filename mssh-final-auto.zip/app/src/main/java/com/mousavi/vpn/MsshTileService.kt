package com.mousavi.vpn

import android.graphics.drawable.Icon
import android.net.VpnService
import android.widget.Toast
import android.content.Intent
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.collect

class MsshTileService : TileService() {
    private var observer: Job? = null
    override fun onStartListening() {
        super.onStartListening()
        observer?.cancel()
        observer = CoroutineScope(Dispatchers.Main).launch {
            TunnelState.status.collect { status ->
                qsTile?.apply {
                    icon = Icon.createWithResource(this@MsshTileService, R.drawable.ic_tile_m)
                    state = if (status.active) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
                    label = "mssh"
                    if (Build.VERSION.SDK_INT >= 29) subtitle = if (status.active) "قطع اتصال" else "اتصال"
                    updateTile()
                }
            }
        }
    }
    override fun onStopListening() { observer?.cancel(); observer = null; super.onStopListening() }
    private fun message(text: String) {
        Toast.makeText(this, text, Toast.LENGTH_LONG).show()
    }

    override fun onClick() {
        super.onClick()
        // Only request unlocking when necessary; some OEMs dismiss the
        // Quick Settings panel even when the device is already unlocked.
        if (isLocked) unlockAndRun { toggleConnection() }
        else toggleConnection()
    }

    private fun toggleConnection() {
        run {
            if (TunnelState.status.value.active) {
                startService(Intent(this, MsshVpnService::class.java).setAction("STOP"))
                return@run
            }
            try {
                val data = ProfileStore(this).load()
                val profile = data.profiles.firstOrNull { it.id == data.selectedId }
                if (profile == null) {
                    message("ابتدا در برنامه یک سرور انتخاب کنید.")
                    return@run
                }
                if (profile.password.isEmpty()) {
                    message("ابتدا رمز سرور را در برنامه ذخیره کنید.")
                    return@run
                }
                val key = HostTrust.saved(this, profile)
                if (key == null || VpnService.prepare(this) != null) {
                    message("برای تأیید کلید سرور و مجوز VPN، یک‌بار از داخل برنامه وصل شوید.")
                    return@run
                }
                TunnelState.pending = ConnectRequest(profile, profile.password, key)
                startForegroundService(Intent(this, MsshVpnService::class.java))
            } catch (_: Exception) {
                TunnelState.pending = null
                message("شروع اتصال ممکن نشد؛ وضعیت را داخل برنامه بررسی کنید.")
            }
        }
    }
}
