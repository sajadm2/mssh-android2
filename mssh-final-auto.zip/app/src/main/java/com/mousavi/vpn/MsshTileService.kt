package com.mousavi.vpn

import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.collect

class MsshTileService : TileService() {
    private var observer: Job? = null
    override fun onStartListening() {
        super.onStartListening()
        observer?.cancel()
        observer = CoroutineScope(Dispatchers.Main).launch {
            TunnelState.status.collect { status ->
                qsTile?.apply {
                    state = if (status.active) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
                    label = "mssh"
                    if (Build.VERSION.SDK_INT >= 29) subtitle = if (status.active) "قطع اتصال" else "اتصال"
                    updateTile()
                }
            }
        }
    }
    override fun onStopListening() { observer?.cancel(); observer = null; super.onStopListening() }
    // The PendingIntent overload exists only on API 34+. Keep the legacy call
    // isolated and runtime-guarded; suppress only this target-SDK-based lint rule.
    @android.annotation.SuppressLint("StartActivityAndCollapseDeprecated")
    @Suppress("DEPRECATION")
    private fun openOnLegacyAndroid(intent: Intent) {
        check(Build.VERSION.SDK_INT < 34)
        startActivityAndCollapse(intent)
    }

    override fun onClick() {
        super.onClick()
        unlockAndRun {
            if (TunnelState.status.value.active) {
                startService(Intent(this, MsshVpnService::class.java).setAction("STOP"))
            } else {
                val intent = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP).putExtra("tile_connect", true)
                if (Build.VERSION.SDK_INT >= 34) startActivityAndCollapse(PendingIntent.getActivity(this, 1, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))
                else openOnLegacyAndroid(intent)
            }
        }
    }
}
