# 0.4.0-sharing (versionCode 5)

- Retains bind-before-protect SSH socket correction.
- Optional per-profile passwords inside existing AES-GCM / Android Keystore storage; password input is not saved into activity instance state.
- Saved password prefilled in connection confirmation dialog.
- mssh:// v1 JSON/base64url import/export via clipboard and QR. This is encoding, NOT encryption. Password export is opt-in. Imported profiles must be reviewed in the editor before saving. SSH trust is never imported.
- QR camera scanning and image import (downsampled before decoding).
- Quick Settings tile: disconnect active tunnel, or open selected-profile connection confirmation. Does not silently connect from lock screen, does not auto-select lowest-latency server from tile. Add through Android Quick Settings edit menu.
- Existing host-key TOFU pin persists by endpoint; changed key still rejected.

## Validation status
No Android SDK/Gradle available in this environment. APK compilation, lint, camera permission flow, QR scanning, and tile lifecycle need GitHub Actions/device testing. ZIP integrity and XML syntax alone do not validate Android runtime functionality.

## Device checklist
1. Install over v0.3.1 with same signing key; existing profiles and trust should remain.
2. Save password opt-in, restart app, connect; turn option off, save, verify prompt is empty next connection.
3. Export without password: import review must have empty password. Export with password: review must contain it; decline saving if unwanted.
4. Scan both camera and image QR; test malformed/oversized input and denied camera permission.
5. Add mssh tile, connect with confirmation; tap again to disconnect; verify lock-screen unlock.
6. Verify same host key does not ask again; changed key must fail, never silently replace pin.
