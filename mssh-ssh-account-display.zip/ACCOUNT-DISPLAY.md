# SSH account display changes

Source-only delivery; Android compilation, signing and device testing have NOT been performed.

- Homepage: estimated remaining time, unlimited volume label, configured display-only user count.
- New manually-created profiles default to 30 days / 1 user. Legacy configs without periodDays show unspecified time.
- mssh:// carries periodDays (0..3650) and userCount (1..999). Imported profiles do not expose editing controls for these fields. This is not tamper protection: unsigned configs can be altered externally.
- First established SSH/VPN starts the local period. Time continues while disconnected. Expiry is persisted by host/port/username (password changes and reimport retain the estimate); clearing app data loses it.
- Only a connection initiated after local expiry is eligible to renew. Renewal requires an HTTPS 204 response through a VPN network while SSH/native forwarding remain running. Failed probes retry at one-minute intervals during that eligible connection.
- No blocking on expiry, no volume accounting, no simultaneous-user enforcement, no provider renewal verification. Wall-clock changes affect the estimate.
- No Xray integration.

## Required checks before release
1. Build debug and release via Android CI; keep existing signing key (alias mssh).
2. Round-trip old/new configs and QR; verify saved encrypted profiles migrate.
3. Verify countdown starts once, persists after process restart/reboot/disconnect, and remains unchanged on reimport.
4. Expired account + failed SSH or blocked tunneled HTTPS: no renewal. Expired account + new working VPN HTTPS: renew once.
5. Connection already running at expiry must not renew until reconnect.
6. Imported account fields are read-only in UI; manual fields validate range.
7. Test phone/small-screen RTL layout and Quick Settings connection path.

Do not publish as tested or signed until these checks pass. Config/QR passwords are not encrypted.
