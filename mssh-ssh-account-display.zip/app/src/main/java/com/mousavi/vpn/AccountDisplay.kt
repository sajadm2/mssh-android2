package com.mousavi.vpn

import android.content.Context
import java.security.MessageDigest

/** Local display estimate, NOT server billing or access enforcement. */
class AccountDisplay(context: Context) {
    private val prefs = context.getSharedPreferences("account_display", Context.MODE_PRIVATE)
    private fun key(p: ServerProfile): String {
        val identity = "${p.host.lowercase(java.util.Locale.ROOT)}\u0000${p.port}\u0000${p.username}"
        return MessageDigest.getInstance("SHA-256").digest(identity.toByteArray()).joinToString("") { "%02x".format(it) }
    }
    fun expiry(p: ServerProfile): Long = prefs.getLong(key(p), 0L)
    fun start(p: ServerProfile) {
        if (p.periodDays <= 0) return
        check(prefs.edit().putLong(key(p), System.currentTimeMillis() + p.periodDays * 86_400_000L).commit())
    }
    fun label(p: ServerProfile): String {
        if (p.periodDays <= 0) return "مشخص نشده"
        val end = expiry(p)
        if (end == 0L) return "${p.periodDays} روز؛ شروع با اولین اتصال"
        val seconds = (end - System.currentTimeMillis()) / 1000
        if (seconds <= 0) return "منقضی شده (نمایشی)"
        return "%d روز %02d:%02d:%02d".format(seconds / 86400, seconds / 3600 % 24, seconds / 60 % 60, seconds % 60)
    }
}
