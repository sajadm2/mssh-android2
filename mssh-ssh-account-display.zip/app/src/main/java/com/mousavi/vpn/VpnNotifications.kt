package com.mousavi.vpn

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context

object VpnNotifications {
    fun allowed(context: Context): Boolean {
        val manager = context.getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(NotificationChannel("vpn", "اتصال mssh", NotificationManager.IMPORTANCE_LOW))
        return manager.areNotificationsEnabled() &&
            manager.getNotificationChannel("vpn").importance != NotificationManager.IMPORTANCE_NONE
    }
}
