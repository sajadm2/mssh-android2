package com.mousavi.vpn

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.SystemClock
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.URL
import javax.net.ssl.HttpsURLConnection

/** HTTPS request time over the VPN network only; never falls back to mobile/Wi-Fi. */
object InternetLatency {
    suspend fun measure(context: Context): Long? = withContext(Dispatchers.IO) {
        val manager = context.getSystemService(ConnectivityManager::class.java)
        val network = manager.allNetworks.firstOrNull {
            manager.getNetworkCapabilities(it)?.hasTransport(NetworkCapabilities.TRANSPORT_VPN) == true
        } ?: return@withContext null
        var connection: HttpsURLConnection? = null
        try {
            val start = SystemClock.elapsedRealtime()
            connection = network.openConnection(URL("https://www.gstatic.com/generate_204")) as HttpsURLConnection
            connection.connectTimeout = 5000
            connection.readTimeout = 5000
            connection.useCaches = false
            connection.instanceFollowRedirects = false
            connection.setRequestProperty("Connection", "close")
            if (connection.responseCode == 204 && TunnelState.status.value.active)
                (SystemClock.elapsedRealtime() - start).coerceAtLeast(1) else null
        } catch (_: java.io.IOException) { null }
        finally { connection?.disconnect() }
    }
}
