package com.mousavi.vpn

import android.os.Bundle
import android.app.Activity
import android.net.VpnService
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import android.content.Intent
import android.net.Uri
import androidx.compose.ui.platform.LocalContext
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import androidx.compose.ui.unit.sp

private val Gold = Color(0xFFE4C688)
private val Panel = Color(0xFF1C2A40)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Gold, surface = Panel, background = Color(0xFF101A2C))) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    var showBrand by rememberSaveable { mutableStateOf(true) }
                    LaunchedEffect(Unit) {
                        kotlinx.coroutines.delay(2_000)
                        showBrand = false
                    }
                    if (showBrand) BrandSplash() else App()
                }
            }
        }
    }
}

@Composable
private fun App() {
    val context = LocalContext.current
    val status by TunnelState.status.collectAsState()
    val scope = rememberCoroutineScope()
    val preferences = remember { context.getSharedPreferences("mssh_options", android.content.Context.MODE_PRIVATE) }
    var automatic by remember { mutableStateOf(preferences.getBoolean("automatic", false)) }
    var internetPing by remember { mutableStateOf<Long?>(null) }
    var internetTested by remember { mutableStateOf(false) }
    LaunchedEffect(status.active) { internetPing = null; internetTested = false }
    var measuring by remember { mutableStateOf(false) }
    var latencies by remember { mutableStateOf<Map<String, Long?>>(emptyMap()) }
    var connectionProfile by remember { mutableStateOf<ServerProfile?>(null) }
    var showConnect by remember { mutableStateOf(false) }
    var password by remember { mutableStateOf("") }
    var fingerprint by remember { mutableStateOf("") }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            context.startForegroundService(Intent(context, MsshVpnService::class.java))
        } else {
            TunnelState.pending?.password = ""
            TunnelState.pending = null
        }
    }
    val store = remember { ProfileStore(context) }
    var storageError by remember { mutableStateOf(false) }
    var data by remember {
        mutableStateOf(try { store.load() } catch (_: Exception) {
            storageError = true
            ProfileData(emptyList(), null)
        })
    }
    var exporting by remember { mutableStateOf<ServerProfile?>(null) }
    var editing by remember { mutableStateOf<ServerProfile?>(null) }
    var showEditor by remember { mutableStateOf(false) }
    var pendingDelete by remember { mutableStateOf<ServerProfile?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    val selected = data.profiles.find { it.id == data.selectedId }
    fun persist(next: ProfileData) {
        try { store.save(next); data = next } catch (_: Exception) {
            error = "ذخیرهٔ امن انجام نشد؛ تغییری اعمال نشده است."
        }
    }
    var notificationRequired by remember { mutableStateOf(false) }
    val notificationPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        notificationRequired = !VpnNotifications.allowed(context)
    }
    fun requireNotifications(): Boolean {
        if (VpnNotifications.allowed(context)) return true
        notificationRequired = true
        return false
    }
    fun connectSaved(profile: ServerProfile): Boolean {
        if (!requireNotifications()) return true
        val key = HostTrust.saved(context, profile) ?: return false
        if (profile.password.isEmpty()) return false
        connectionProfile = profile
        TunnelState.pending = ConnectRequest(profile, profile.password, key)
        val consent = VpnService.prepare(context)
        if (consent == null) context.startForegroundService(Intent(context, MsshVpnService::class.java))
        else permissionLauncher.launch(consent)
        return true
    }
    var showHelp by rememberSaveable { mutableStateOf(false) }
    var settingsDetails by remember { mutableStateOf(false) }
    var tab by rememberSaveable { mutableIntStateOf(0) }
    LaunchedEffect(Unit) {
        val activity = context as? Activity
        if (activity?.intent?.getBooleanExtra("tile_connect", false) == true) {
            activity.intent.removeExtra("tile_connect")
            if (!status.active && selected != null) {
                if (!connectSaved(selected)) {
                    connectionProfile = selected; password = selected.password; fingerprint = ""; showConnect = true
                }
            } else if (selected == null) tab = 1
        }
    }
    Scaffold(
        bottomBar = {
            NavigationBar(containerColor = Panel) {
                listOf("اتصال", "سرورها", "تنظیمات").forEachIndexed { index, title ->
                    NavigationBarItem(selected = tab == index, onClick = { tab = index },
                        icon = { Text(listOf("◉", "☰", "⚙")[index]) }, label = { Text(title) })
                }
            }
        }
    ) { padding ->
        Column(
            Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF17243A), Color(0xFF090F1C))))
                .padding(padding).padding(horizontal = 20.dp, vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text("mssh", color = Gold, fontSize = 22.sp)
            if (storageError) Text("خواندن پروفایل‌های رمزگذاری‌شده ممکن نشد. برای حفظ داده‌ها، ویرایش غیرفعال است.", color = Color(0xFFFF8080))
            when (tab) {
                0 -> {
                    val displayedProfile = if (automatic) connectionProfile ?: selected else selected
                    Text(displayedProfile?.name ?: if (automatic) "انتخاب خودکار سرور" else "سروری انتخاب نشده", color = Gold, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = automatic, enabled = !status.active && !measuring, onCheckedChange = {
                            automatic = it
                            preferences.edit().putBoolean("automatic", it).apply()
                        })
                        Text("انتخاب خودکار کمترین پینگ")
                    }
                    val accountProfile = if (status.active) TunnelState.displayProfile ?: displayedProfile else displayedProfile
                    val accountDisplay = remember { AccountDisplay(context) }
                    var remaining by remember { mutableStateOf("") }
                    LaunchedEffect(accountProfile) {
                        while (true) {
                            remaining = accountProfile?.let { accountDisplay.label(it) } ?: "سروری انتخاب نشده"
                            kotlinx.coroutines.delay(1000)
                        }
                    }
                    Text("زمان باقی‌مانده: $remaining", color = Gold, fontSize = 13.sp)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                        Text("حجم: نامحدود", fontSize = 13.sp)
                        Text("تعداد کاربر: ${accountProfile?.userCount?.toString() ?: "—"}", fontSize = 13.sp)
                    }
                    Text("اعتبار تخمینی است؛ کنترل واقعی با سرور است.", fontSize = 11.sp)
                    if (measuring) Text("در حال بررسی سرورها…")
                    Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Button(enabled = !measuring, onClick = {
                        if (status.active) context.startService(Intent(context, MsshVpnService::class.java).setAction("STOP"))
                        else if (data.profiles.isEmpty()) tab = 1
                        else if (automatic) {
                            val candidates = data.profiles.toList()
                            measuring = true
                            scope.launch {
                                try {
                                    val results = ServerLatency.measure(candidates)
                                    latencies = results
                                    val best = candidates.filter { results[it.id] != null }
                                        .minByOrNull { results[it.id]!! }
                                    if (best == null) error = "هیچ سروری پاسخ نداد؛ شبکه یا مشخصات سرورها را بررسی کنید."
                                    else {
                                        if (!connectSaved(best)) {
                                            connectionProfile = best
                                            fingerprint = ""; password = best.password
                                            showConnect = true
                                        }
                                    }
                                } finally { measuring = false }
                            }
                        } else if (selected == null) tab = 1
                        else if (!connectSaved(selected)) { connectionProfile = selected; fingerprint = ""; password = selected.password; showConnect = true }
                    }, shape = CircleShape,
                        modifier = Modifier.sizeIn(maxWidth = 164.dp, maxHeight = 164.dp).aspectRatio(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = Panel,
                            contentColor = if (status.connected) Color(0xFF32D583) else Color(0xFFFF303B))) {
                        Text("M", fontSize = 88.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Black)
                    }
                    }
                    OutlinedButton(enabled = !measuring && (displayedProfile != null || (automatic && data.profiles.isNotEmpty())), onClick = {
                        val targets = if (automatic && !status.active) data.profiles.toList() else listOfNotNull(displayedProfile)
                        measuring = true
                        scope.launch {
                            try {
                                if (status.active) {
                                    internetPing = InternetLatency.measure(context)
                                    internetTested = true
                                } else latencies = latencies + ServerLatency.measure(targets)
                            }
                            finally { measuring = false }
                        }
                    }) {
                        Text(if (measuring) "در حال پینگ…" else "پینگ")
                    }
                    val pingResult = displayedProfile?.let { profile ->
                        if (latencies.containsKey(profile.id)) latencies[profile.id]?.let { "پینگ TCP: $it ms" } ?: "پینگ TCP: بدون پاسخ"
                        else null
                    }
                    Text(if (status.active) {
                        if (internetTested) internetPing?.let { "تأخیر HTTPS از تونل: $it ms" } ?: "مقصد تست اینترنت پاسخ نداد"
                        else "پینگ اینترنت از داخل تونل"
                    } else pingResult ?: "تست پاسخ پورت SSH، نه دسترسی اینترنت", color = Gold, fontSize = 12.sp)
                    Text(status.text, fontSize = 16.sp, maxLines = 2, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                    Text("%02d:%02d:%02d".format(status.seconds / 3600, status.seconds / 60 % 60, status.seconds % 60), fontSize = 30.sp)
                    Text("↓ ${status.download / 1024} KiB     ↑ ${status.upload / 1024} KiB", fontSize = 14.sp)
                    Text("SSH مستقیم • فقط TCP • UDP عمومی پشتیبانی نمی‌شود", color = Gold, fontSize = 13.sp)
                }
                1 -> {
                    Button(enabled = !storageError, onClick = { editing = null; showEditor = true }) { Text("افزودن سرور SSH") }
                    ImportControls(enabled = !storageError, onImport = { editing = it; showEditor = true }, onError = { error = it })
                    if (data.profiles.isEmpty()) InfoCard("پروفایل‌های SSH", "سرور اضافه کنید یا کانفیگ mssh وارد کنید. رمز واردشده به‌صورت امن ذخیره می‌شود.")
                    LazyColumn(
                        modifier = Modifier.fillMaxWidth().weight(1f),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                    items(data.profiles, key = { it.id }) { profile ->
                        Surface(shape = RoundedCornerShape(20.dp), color = Panel) {
                            Column(Modifier.fillMaxWidth().padding(16.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(profile.name, color = Gold, modifier = Modifier.weight(1f), maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                                    TextButton(enabled = !storageError, onClick = { editing = profile; showEditor = true }) { Text("ویرایش") }
                                    TextButton(onClick = { exporting = profile }) { Text("اشتراک") }
                                    TextButton(enabled = !storageError, onClick = { pendingDelete = profile }) { Text("حذف") }
                                }
                                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                                    Text("${profile.host}:${profile.port}", maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                                }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    TextButton(enabled = !storageError && !automatic && !measuring && !status.active, onClick = { persist(data.copy(selectedId = profile.id)) }) {
                                        Text(if (selected?.id == profile.id) "انتخاب‌شده ✓" else "انتخاب")
                                    }
                                    Spacer(Modifier.weight(1f))
                                    Text(if (latencies.containsKey(profile.id)) latencies[profile.id]?.let { "SSH • $it ms" } ?: "SSH • بدون پاسخ" else "SSH • تست نشده", color = Gold, fontSize = 12.sp)
                                }
                            }
                        }
                    }
                    }
                }
                2 -> {
                    Button(onClick = { showHelp = true }, modifier = Modifier.fillMaxWidth()) {
                        Text("راهنمای استفاده و رفع مشکل")
                    }
                    TextButton(onClick = { settingsDetails = true }) { Text("اطلاعات، حریم خصوصی و محدودیت‌ها") }
                    OutlinedButton(onClick = {
                        try {
                            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/light_elc")))
                        } catch (_: android.content.ActivityNotFoundException) {
                            error = "برای باز کردن لینک، مرورگر یا تلگرام نصب کنید."
                        }
                    }, modifier = Modifier.fillMaxWidth()) {
                        Text("پشتیبانی تلگرام — @light_elc")
                    }
                    Text("انتخاب خودکار بر اساس تأخیر TCP پورت SSH است؛ نه سرعت دانلود یا تضمین اینترنت.", fontSize = 13.sp)
                }
            }
        }
    }
    if (notificationRequired) AlertDialog(
        onDismissRequest = { notificationRequired = false },
        title = { Text("اعلان اتصال لازم است") },
        text = { Text("برای نمایش وضعیت VPN و دکمهٔ قطع، اعلان‌های mssh و دستهٔ اتصال را فعال کنید؛ سپس دوباره اتصال را بزنید.") },
        confirmButton = { TextButton(onClick = {
            if (android.os.Build.VERSION.SDK_INT >= 33 && context.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                notificationPermission.launch(android.Manifest.permission.POST_NOTIFICATIONS)
            } else {
                context.startActivity(Intent(android.provider.Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS)
                    .putExtra(android.provider.Settings.EXTRA_APP_PACKAGE, context.packageName)
                    .putExtra(android.provider.Settings.EXTRA_CHANNEL_ID, "vpn"))
            }
        }) { Text("اجازهٔ اعلان") } },
        dismissButton = { TextButton(onClick = {
            context.startActivity(Intent(android.provider.Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                .putExtra(android.provider.Settings.EXTRA_APP_PACKAGE, context.packageName))
        }) { Text("تنظیمات اعلان") } }
    )
    if (settingsDetails) AlertDialog(
        onDismissRequest = { settingsDetails = false },
        title = { Text("اطلاعات برنامه") },
        confirmButton = { TextButton(onClick = { settingsDetails = false }) { Text("بستن") } },
        text = { Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    InfoCard("محدودیت‌ها", "UDP، اتصال مجدد خودکار، کلید خصوصی، انتخاب برنامه‌ها و ورود کانفیگ npvt هنوز پشتیبانی نمی‌شوند. با قطع سرویس، اینترنت عادی برمی‌گردد؛ Kill Switch پیاده‌سازی نشده است.")
                    InfoCard("میانبر پردهٔ تنظیمات سریع", "پردهٔ تنظیمات سریع گوشی را باز کنید، ویرایش / مداد را بزنید و کاشی mssh را اضافه کنید. وقتی متصل هستید قطع می‌کند؛ در حالت قطع، بدون باز کردن برنامه به سرور انتخاب‌شده وصل می‌شود. رمز باید ذخیره شده و کلید سرور و مجوز VPN قبلاً تأیید شده باشند.")
                    InfoCard("حریم خصوصی", "پروفایل‌ها و رمزهای اختیاری با AES-GCM و Android Keystore ذخیره می‌شوند. کانفیگ کپی‌شده و QR رمزگذاری نیستند. اعتماد به کلید SSH برای همان میزبان و پورت ذخیره می‌شود؛ تغییر کلید اتصال را متوقف می‌کند.")
        } }
    )
    if (showHelp) HelpDialog(onDismiss = { showHelp = false })
    exporting?.let { ExportDialog(it, onDismiss = { exporting = null }) }
    if (showEditor) ProfileEditor(editing, onDismiss = { showEditor = false }, onSave = { profile ->
        val profiles = data.profiles.filterNot { it.id == profile.id } + profile
        persist(ProfileData(profiles, data.selectedId ?: profile.id))
        showEditor = false
    })
    pendingDelete?.let { profile ->
        AlertDialog(onDismissRequest = { pendingDelete = null }, title = { Text("حذف پروفایل؟") },
            text = { Text(profile.name) }, confirmButton = {
                TextButton(onClick = {
                    val remaining = data.profiles.filterNot { it.id == profile.id }
                    persist(ProfileData(remaining, if (data.selectedId == profile.id) remaining.firstOrNull()?.id else data.selectedId))
                    pendingDelete = null
                }) { Text("حذف") }
            }, dismissButton = { TextButton(onClick = { pendingDelete = null }) { Text("انصراف") } })
    }
    error?.let { message ->
        AlertDialog(onDismissRequest = { error = null }, title = { Text("خطا") }, text = { Text(message) },
            confirmButton = { TextButton(onClick = { error = null }) { Text("بستن") } })
    }
    if (showConnect) {
        var loadingKey by remember { mutableStateOf(true) }
        var trustedKey by remember { mutableStateOf(false) }
        var keyError by remember { mutableStateOf<String?>(null) }
        LaunchedEffect(connectionProfile) {
            fingerprint = ""
            val profile = connectionProfile
            try {
                if (profile != null) {
                    val saved = HostTrust.saved(context, profile)
                    if (saved != null) { fingerprint = saved; trustedKey = true }
                    else fingerprint = HostTrust.discover(profile)
                }
            } catch (e: kotlinx.coroutines.CancellationException) { throw e
            } catch (_: Exception) {
                keyError = "دریافت کلید سرور ممکن نشد؛ اینترنت، آدرس و پورت را بررسی کنید و دوباره تلاش کنید."
            } finally { loadingKey = false }
        }
        AlertDialog(onDismissRequest = { showConnect = false; password = "" },
            title = { Text("اتصال به ${connectionProfile?.name.orEmpty()}") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    if (connectionProfile?.password.isNullOrEmpty()) {
                        Text("رمز در این پروفایل ذخیره نشده است؛ برای اتصال بدون درخواست رمز، آن را در ویرایش سرور ذخیره کنید.")
                        OutlinedTextField(value = password, onValueChange = { password = it }, singleLine = true,
                            label = { Text("رمز SSH") }, visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation())
                    }
                    if (loadingKey) { CircularProgressIndicator(); Text("در حال دریافت کلید سرور…") }
                    keyError?.let { Text(it, color = Color(0xFFFF8080)) }
                    if (trustedKey) Text("کلید ذخیره‌شده هنگام اتصال بررسی می‌شود؛ تغییر کلید باعث توقف اتصال خواهد شد.")
                    else if (fingerprint.isNotEmpty()) {
                        Text(fingerprint, style = MaterialTheme.typography.bodySmall)
                        Text("اولین اتصال: بدون مقایسه با مقدار معتبر، هویت سرور تضمین نمی‌شود. فقط در صورت اعتماد به این اتصال تأیید کنید.")
                        Text("با زدن «اعتماد و اتصال»، این کلید ذخیره می‌شود؛ تغییر بعدی کلید اتصال را متوقف می‌کند.")
                    }
                    Text("TCP تونل می‌شود؛ تماس‌ها و بازی‌های نیازمند UDP ممکن است کار نکنند. هنگام قطع VPN اینترنت عادی برمی‌گردد.")
                }
            },
            confirmButton = { TextButton(enabled = password.isNotEmpty() && !loadingKey && fingerprint.isNotEmpty(), onClick = {
                if (!requireNotifications()) return@TextButton
                connectionProfile?.let { profile ->
                    if (!trustedKey && !HostTrust.save(context, profile, fingerprint)) {
                        error = "ذخیرهٔ کلید سرور انجام نشد؛ اتصال متوقف شد."
                        return@let
                    }
                    TunnelState.pending = ConnectRequest(profile, password, fingerprint.trim())
                    password = ""; showConnect = false
                    val consent = VpnService.prepare(context)
                    if (consent == null) context.startForegroundService(Intent(context, MsshVpnService::class.java))
                    else permissionLauncher.launch(consent)
                }
            }) { Text(if (trustedKey) "اتصال" else "اعتماد و اتصال") } },
            dismissButton = { TextButton(onClick = { showConnect = false; password = "" }) { Text("انصراف") } })
    }
}

@Composable
private fun InfoCard(title: String, value: String) {
    Surface(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp), color = Panel) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, color = Color(0xFF8E9EB5), fontSize = 13.sp)
            Text(value, color = Color(0xFFF0F4FB), fontSize = 16.sp)
        }
    }
}
